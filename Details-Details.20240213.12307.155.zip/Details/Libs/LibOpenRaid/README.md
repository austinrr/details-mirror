# Open-Raid-Library
Library for World of Warcraft game, help to transmit data among players in a group
