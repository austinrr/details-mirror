# Details! Damage Meter

## [Details.20240213.12307.155](https://github.com/Tercioo/Details-Damage-Meter/tree/Details.20240213.12307.155) (2024-02-13)
[Full Changelog](https://github.com/Tercioo/Details-Damage-Meter/compare/Details.20240208.12294.155...Details.20240213.12307.155) 

- General development and bug fixes (see commit description).  
    - Fixed the deaths display, where the windows wasn't usig custom text scripts.  
    - Fixed an issue with custom displays, where it was unable to use class colors in their texts.  
    - More development and bug fixes on the new Mythic+ Run Completion panel.  
    - Framework Update.  
